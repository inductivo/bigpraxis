$(function() {
  var header = document.getElementById('app-header')
  var seleccion = $([ document, header ]);

  $(':checkbox')
})